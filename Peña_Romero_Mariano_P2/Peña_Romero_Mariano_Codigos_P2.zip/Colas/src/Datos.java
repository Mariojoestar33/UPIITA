public class Datos {

    private int prioridad;
    private int datos;

    public Datos(int prioridad, int datos) {
        this.prioridad = prioridad;
        this.datos = datos;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getDatos() {
        return datos;
    }

    public void setDatos(int datos) {
        this.datos = datos;
    }
    
}
